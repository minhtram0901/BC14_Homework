// Bài 1: Tính tiền lương nhân viên
var salaryPerDay = 100000;
var workingDay = 22;
var monthlySalary = salaryPerDay * workingDay;

console.log("Bài tập 1");
console.log("Tiền lương 1 ngày: " + salaryPerDay + " vnd");
console.log("Số ngày công: " + workingDay);
console.log("Tiền lương một tháng: " + monthlySalary + " vnd");
console.log("-----------------------------");

// Bài 2: Tính giá trị trung bình
var num1 = 100;
var num2 = 50;
var num3 = 30;
var num4 = 35;
var num5 = 40;

var average = (num1 + num2 + num3 + num4 +num5)/5;
console.log("Bài tập 2");
console.log("Số thứ 1: " + num1);
console.log("Số thứ 2: " + num2);
console.log("Số thứ 3: " + num3);
console.log("Số thứ 4: " + num4);
console.log("Số thứ 5: " + num5);
console.log("Trung bình cộng của 5 số = " + average );
console.log("-----------------------------");

// Bài 3: Quy đổi tiền
var usdRate = 23500;
var usd = 100;
var vnd = usd * usdRate;

console.log("Bài tập 3");
console.log("Tỷ giá: 1USD = " + usdRate + " vnd");
console.log("Quy đổi: " + usd + " usd = " + vnd + " vnd");
console.log("-----------------------------");

// Bài 4: Tính diện tích, chu vi hình chữ nhật
var rong = 100;
var dai = 100;
var chuVi = (dai + rong) * 2;
var dienTich = dai * rong;

console.log("Bài tập 4");
console.log("Hình chữ nhật " + rong + " x " + dai);
console.log("Chu vi = " + chuVi);
console.log("Diện tích = " + dienTich);
console.log("-----------------------------");

// Bài 5: Tính tổng 2 ký số
var num = 57;
var donVi = num % 10;
var chuc = Math.floor(num / 10);
var tong = donVi + chuc;

console.log("Bài tập 5");
console.log("Số có 2 ký tự: " + num);
console.log("Tổng 2 ký số = " + chuc + " + " + donVi + " = " + tong);
console.log("-----------------------------");