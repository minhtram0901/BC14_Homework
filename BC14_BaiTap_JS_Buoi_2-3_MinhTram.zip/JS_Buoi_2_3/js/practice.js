// Bài 1: Tính tiền lương nhân viên
function tinhTienLuong(){
    var luongNgay = document.getElementById("salaryPerDay").value;
    var soNgay = document.getElementById("workingDay").value;
    var luongThang = luongNgay * soNgay;

    var pResult = document.getElementById("outputStr1");
    pResult.innerHTML =  "Tiền lương tháng = " + luongThang + " vnd";
}
// Bài 2: Tính giá trị trung bình
function tinhTrungBinh(){
    var num1 = Number(document.getElementById("num1").value);
    var num2 = Number(document.getElementById("num2").value);
    var num3 = Number(document.getElementById("num3").value);
    var num4 = Number(document.getElementById("num4").value);
    var num5 = Number(document.getElementById("num5").value);
    var output = document.getElementById("avg");

    var average = (num1 + num2 + num3 + num4 +num5) / 5;
    output.value = average.toFixed(2);
}

// Bài 3: Quy đổi tiền
function quyDoi(){
    var usdRate = Number(document.getElementById("usdRate").value);
    var usd = Number(document.getElementById("usd").value);
    var vnd = usd * usdRate;

    var pResult = document.getElementById("outputStr2");
    pResult.innerHTML =  usd + " USD = " + vnd + " VND";
}


// Bài 4: Tính diện tích, chu vi hình chữ nhật
function tinhToan(){
    var rong = Number(document.getElementById("width").value);
    var dai = Number(document.getElementById("length").value);
    var chuVi = (dai + rong) * 2;
    var dienTich = dai * rong;

    var pResult = document.getElementById("outputStr3");
    pResult.innerHTML =  "Chu vi = " + chuVi + "<br>Diện tích = " + dienTich;
}

// Bài 5: Tính tổng 2 ký số
function tongKySo(){
    var num = Number(document.getElementById("number").value);
    var donVi = num % 10;
    var chuc = Math.floor(num / 10);
    var tong = donVi + chuc;

    var pResult = document.getElementById("outputStr4");
    pResult.innerHTML =  "Tổng 2 ký số = " + chuc + " + " + donVi + " = " + tong;
}